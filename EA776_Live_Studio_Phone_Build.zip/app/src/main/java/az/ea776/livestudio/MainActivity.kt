package az.ea776.livestudio

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Gift
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Night = Color(0xFF090414)
private val Purple = Color(0xFF7B2CFF)
private val Pink = Color(0xFFFF2F9B)
private val Gold = Color(0xFFFFC94A)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            EAStudioApp(
                speak = { message ->
                    if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_ADD, null, "ea776-${System.currentTimeMillis()}")
                }
            )
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            val result = tts?.setLanguage(Locale("az", "AZ"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("tr", "TR"))
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

data class LiveEvent(val user: String, val message: String, val icon: String)

@Composable
fun EAStudioApp(speak: (String) -> Unit) {
    var events by remember {
        mutableStateOf(
            listOf(
                LiveEvent("Leyla_777", "Salam, əla yayım ❤️", "💬"),
                LiveEvent("Murad_123", "Rose göndərdi", "🌹"),
                LiveEvent("Aysel_M", "Galaxy göndərdi", "🌌")
            )
        )
    }
    var lionWaves by remember { mutableStateOf(false) }
    var soundOn by remember { mutableStateOf(true) }
    var totalGifts by remember { mutableIntStateOf(0) }
    var likes by remember { mutableIntStateOf(4800) }

    val waveScale by animateFloatAsState(if (lionWaves) 1.08f else 1f, label = "lionWave")

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Pink, secondary = Purple, background = Night, surface = Color(0xFF1A1030)
    )) {
        Box(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF17052E), Night, Color(0xFF100725)))
            )
        ) {
            Column(Modifier.fillMaxSize().padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(58.dp).background(Brush.linearGradient(listOf(Gold, Purple)), CircleShape), contentAlignment = Alignment.Center) {
                        Text("🦁", fontSize = 30.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("E.A.776 LIVE STUDIO", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text("Android canlı yayım köməkçisi", color = Color(0xFFD6BFFF), fontSize = 12.sp)
                    }
                    IconButton(onClick = { soundOn = !soundOn }) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "Səs", tint = if (soundOn) Gold else Color.Gray)
                    }
                }

                Spacer(Modifier.height(14.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF24113D)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🦁", fontSize = 92.sp, modifier = Modifier.scale(waveScale))
                        Text("E.A.776", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
                        Text(if (lionWaves) "Salam! Hədiyyəniz üçün çox sağ olun! 👋" else "Canlı yayım personajınız", color = Color.White, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = {
                                lionWaves = !lionWaves
                                if (soundOn) speak("Salam! E.A.776 canlı yayımına xoş gəlmisiniz!")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Pink)
                        ) { Text("👋  Şiri salamlat") }
                    }
                }

                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    StatChip("❤️", likes.toString(), Modifier.weight(1f))
                    StatChip("🎁", totalGifts.toString(), Modifier.weight(1f))
                    StatChip("💬", events.size.toString(), Modifier.weight(1f))
                }

                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Message, contentDescription = null, tint = Pink)
                    Spacer(Modifier.width(7.dp))
                    Text("Canlı şərhlər və hədiyyələr", color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(7.dp))
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(events.reversed()) { event ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF24143B)), shape = RoundedCornerShape(14.dp)) {
                            Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(event.icon, fontSize = 24.sp)
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(event.user, color = Gold, fontWeight = FontWeight.Bold)
                                    Text(event.message, color = Color.White)
                                }
                            }
                        }
                    }
                }

                Text("SINAQ REJİMİ — TikTok-a hələ qoşulmayıb", color = Color(0xFFFFD66B), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = {
                            events = events + LiveEvent("Yeni_izləyici", "Xoş gəldin! 👋", "👤")
                            if (soundOn) speak("Yeni izləyicimiz, xoş gəlmisiniz!")
                            lionWaves = true
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple)
                    ) { Text("İzləyici sınağı") }
                    Button(
                        onClick = {
                            val gift = listOf("Rose", "Heart", "Galaxy").random()
                            val emoji = when (gift) { "Rose" -> "🌹"; "Heart" -> "❤️"; else -> "🌌" }
                            val user = listOf("Murad_123", "Aysel_M", "Leyla_777").random()
                            events = events + LiveEvent(user, "$gift hədiyyəsi göndərdi!", emoji)
                            totalGifts++
                            lionWaves = true
                            if (soundOn) speak("$user, $gift hədiyyəsi üçün çox sağ ol!")
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Pink)
                    ) { Text("Hədiyyə sınağı") }
                }
            }
        }
    }
}

@Composable
fun StatChip(icon: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF24143B)), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Text(icon)
            Spacer(Modifier.width(5.dp))
            Text(value, color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}
