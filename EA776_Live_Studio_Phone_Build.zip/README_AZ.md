# E.A.776 LIVE STUDIO — Android başlanğıc layihəsi

Bu arxiv Android Studio-da açılmaq üçün hazırlanmış Kotlin + Jetpack Compose mənbə layihəsidir.

## Hazır olanlar
- E.A.776 LIVE STUDIO üçün ilkin qaranlıq/neon idarəetmə ekranı
- Şir personajı üçün ilkin emoji maketi
- Şərh və hədiyyə hadisələrinin sınaq simulyasiyası
- Android TextToSpeech ilə Azərbaycan dili səs seçimi (cihazda mövcud TTS səsindən asılıdır)
- Səs düyməsi və sınaq düymələri

## Hələ hazır olmayanlar
- TikTok LIVE-a real qoşulma
- TikTok-dan real hədiyyə/şərh/izləyici məlumatlarının alınması
- Digər tətbiqin üzərində görünən overlay
- Tam animasiyalı, xüsusi çəkilmiş şir modeli

TikTok inteqrasiyası ayrıca araşdırılmalı və təhlükəsiz, platforma qaydalarına uyğun giriş üsulu seçilməlidir. Bu layihədə TikTok hesabı/parolu tələb olunmur.

## APK necə yığılır
1. Android Studio quraşdırın.
2. `EA776LiveStudio` qovluğunu Android Studio ilə açın.
3. Gradle sinxronizasiyasının bitməsini gözləyin.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
5. APK adətən `app/build/outputs/apk/debug/app-debug.apk` qovluğunda yaranır.

Tələb olunan mühit: Android Studio, JDK 17 və Android SDK 35.

## Telefonda kompütersiz APK yığmaq
Bu layihəyə GitHub Actions üçün avtomatik build faylı əlavə olunub:
`.github/workflows/android.yml`

Layihəni GitHub repozitoriyasına yüklədikdən sonra:
1. GitHub-da repozitoriyanı açın.
2. Actions bölməsinə daxil olun.
3. `Build E.A.776 Android APK` iş axınını seçin.
4. `Run workflow` düyməsinə basın.
5. Build bitəndə həmin run səhifəsinin Artifacts hissəsindən APK arxivini yükləyin.
